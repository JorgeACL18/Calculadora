package Calculadora;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            InetSocketAddress dir = new InetSocketAddress("localhost", 8080);
            Socket socket = new Socket();
            socket.connect(dir);

            System.out.println("Conectando al servidor");
            System.out.println("Servidor conectado");

            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader lector = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            while (true) {
                System.out.println("Escribe tu operación (solo dos números) o escribe 'ejemplos' para mostrar las operaciones disponibles:");
                String mensaje = sc.nextLine().trim();

                if (mensaje.isEmpty()) continue;
                out.println(mensaje);

                System.out.println("El servidor ha recibido tu operación");

                if (mensaje.equalsIgnoreCase("adios")) {
                    System.out.println("Saliendo del programa");
                    break;
                }

                if (mensaje.equalsIgnoreCase("ejemplos")) {
                    System.out.println("Operaciones disponibles:");
                    System.out.println("- Suma: 'suma' 'Primer número' 'Segundo número'");
                    System.out.println("- Restar: 'resta' 'Primer número' 'Segundo número'");
                    System.out.println("- Multiplicación: 'mult' 'Primer número' 'Segundo número'");
                    System.out.println("- División: 'div' 'Primer número' 'Segundo número'");
                }

                String respuesta = lector.readLine();
                if (respuesta != null) {
                    System.out.println("Resultado: " + respuesta);
                } else {
                    System.out.println("El servidor cerró la conexión");
                    break;
                }
            }

            sc.close();
            socket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}