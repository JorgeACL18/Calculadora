package Calculadora;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
    public static void main(String[] args){
        ServerSocket servidor = null;
        Socket socket = null;
        try {
            InetSocketAddress dir = new InetSocketAddress("localhost", 8080);
            servidor = new ServerSocket();
            servidor.bind(dir);

            System.out.println("Esperando conexiones...");
            socket = servidor.accept();
            System.out.println("Cliente conectado");

            BufferedReader lector = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out =  new PrintWriter(socket.getOutputStream(), true);

            String mensaje;
            while ((mensaje = lector.readLine()) != null) {
                System.out.println("Operación recibida: " + mensaje);

                if ("adios".equalsIgnoreCase(mensaje)) {
                    System.out.println("El cliente ha escrito 'adios'. Cerrando conexión");
                    break;
                }

                String resultado = resolviendoOP(mensaje);
                out.println(resultado);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (servidor != null) servidor.close();
                if (socket != null) socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static String resolviendoOP (String ent) {
        String comando = ent.trim();

        if ("ejemplos".equalsIgnoreCase(comando)) {
            return "Mostrando ejemplos";
        }

        String[] partes = ent.trim().split("\\s+");
        if (partes.length < 2) {
            return "Error: formato inválido";
        }

        String op = partes[0].toLowerCase();
        try {
            switch (op) {
                case "suma":
                    if (partes.length < 3) return "ERROR: se necesitan al menos 2 números";
                    double resSum = Double.parseDouble(partes[1]);
                    for (int i = 2; i < partes.length; i++) {
                        resSum += Double.parseDouble(partes[i]);
                    }
                    return String.valueOf(resSum);

                case "resta":
                    if (partes.length < 3) return "ERROR: se necesitan al menos 2 números";
                    double resRes = Double.parseDouble(partes[1]);
                    for (int i = 2; i < partes.length; i++) {
                        resRes -= Double.parseDouble(partes[i]);
                    }
                    return String.valueOf(resRes);

                case "mult":
                    if (partes.length < 3) return "ERROR: se necesitan al menos 2 números";
                    double resMul = Double.parseDouble(partes[1]);
                    for (int i = 2; i < partes.length; i++) {
                        resMul *= Double.parseDouble(partes[i]);
                    }
                    return String.valueOf(resMul);

                case "div":
                    if (partes.length < 3) return "ERROR: se necesitan al menos 2 números";
                    double resDiv = Double.parseDouble(partes[1]);
                    for (int i = 2; i < partes.length; i++) {
                        double d = Double.parseDouble(partes[i]);
                        if (d == 0) return "ERROR: división por cero";
                        resDiv /= d;
                    }
                    return String.valueOf(resDiv);

                default:
                    return "ERROR: operación desconocida";
            }
        } catch (NumberFormatException e) {
            return "ERROR: argumento no numérico";
        } catch (Exception e) {
            return "ERROR: excepción inesperada";
        }
    }
}