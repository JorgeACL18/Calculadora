package Calculadora;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
    public static void main(String[] args){
        ServerSocket servidor = null;
        Socket socket = null;
        try {
            InetSocketAddress dir = new InetSocketAddress("localhost", 8080);
            servidor = new ServerSocket();
            servidor.bind(dir);

            System.out.println("Esperando conexiones...");
            socket = servidor.accept();
            System.out.println("Cliente conectado");

            BufferedReader lector = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out =  new PrintWriter(socket.getOutputStream(), true);

            String mensaje;
            while ((mensaje = lector.readLine()) != null) {
                System.out.println("Operación recibida: " + mensaje);

                if ("adios".equalsIgnoreCase(mensaje)) {
                    System.out.println("El cliente ha escrito 'adios'. Cerrando conexión");
                    break;
                }

                /*if ("ejemplos".equalsIgnoreCase(mensaje)) {
                    System.out.println("Operciones disponibles:" +
                            "- Suma: 'suma' 'Primer número' 'Segundo número'" +
                            "- Restar: 'resta' 'Primer número' 'Segundo número'" +
                            "- Multiplicación: 'mult' 'Primer número' 'Segundo número'" +
                            "- División: 'div' 'Primer número' 'Segundo número'");
                }*/

                String resultado = resolviendoOP(mensaje);
                out.println(resultado);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (servidor != null) servidor.close();
                if (socket != null) socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static String resolviendoOP (String ent) {
        String comando = ent.trim();

        if ("ejemplos".equalsIgnoreCase(comando)) {
            return "Mostrando ejemplos";
        }

        String[] partes = ent.trim().split("\\s+");
        if (partes.length < 2) {
            return "Error: formato inválido";
        }

        String op = partes[0].toLowerCase();
        try {
            switch (op) {
                case "suma":
                    if (partes.length != 3) return "ERROR: se esperan 2 operandos";
                    return String.valueOf(Double.parseDouble(partes[1]) + Double.parseDouble(partes[2]));

                case "resta":
                    if (partes.length != 3) return "ERROR: se esperan 2 operandos";
                    return String.valueOf(Double.parseDouble(partes[1]) - Double.parseDouble(partes[2]));

                case "mult":
                    if (partes.length != 3) return "ERROR: se esperan 2 operandos";
                    return String.valueOf(Double.parseDouble(partes[1]) * Double.parseDouble(partes[2]));

                case "div":
                    if (partes.length != 3) return "ERROR: se esperan 2 operandos";
                    double divisor = Double.parseDouble(partes[2]);
                    if (divisor == 0) return "ERROR: división por cero";
                    return String.valueOf(Double.parseDouble(partes[1]) / divisor);

                default:
                    return "ERROR: operación desconocida";
            }
        } catch (NumberFormatException e) {
            return "ERROR: argumento no numérico";
        } catch (Exception e) {
            return "ERROR: excepción inesperada";
        }
    }
}